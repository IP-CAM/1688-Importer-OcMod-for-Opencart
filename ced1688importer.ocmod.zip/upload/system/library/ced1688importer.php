<?php

require_once DIR_SYSTEM . "library/ced1688importer/Generate.php";

class Ced1688Importer
{
    private static $instance;
    private $db;
    private $session;
    private $config;
    private $currency;
    private $request;
    private $weight;
    protected $endpointUrl = '';
    protected $otKey = '';
    protected $language = '';

    /**
     * @param  object $registry Registry Object
     */
    public function __construct($registry)
    {
        $this->db = $registry->get('db');
        $this->session = $registry->get('session');
        $this->config = $registry->get('config');
        $this->currency = $registry->get('currency');
        $this->request = $registry->get('request');
        $this->weight = $registry->get('weight');
    }

    /**
     * @param  object $registry Registry Object
     */
    public static function getInstance($registry)
    {
        if (is_null(static::$instance)) {
            static::$instance = new static($registry);
        }

        return static::$instance;
    }

    public function _init()
    {
        $this->endpointUrl = "http://otapi.net/OtapiWebService2.asmx/";
        //   $this->otKey = "opendemo";
        $this->otKey = $this->config->get('ced_1688_importer_ot_key');
        $this->language = $this->config->get('ced_1688_importer_language');
    }

    public function isEnabled()
    {
        $flag = false;
        if ($this->config->get('ced_1688_importer_status')) {
            $flag = true;
            $this->_init();
        }
        return $flag;
    }

    public function isInstalled()
    {
        if ($this->db->query("SHOW TABLES LIKE '" . DB_PREFIX . "ced_1688_importer_settings'")->num_rows) {
            return true;
        } else {
            return false;
        }
    }

    public function install()
    {
        $ced1688_importer_product_attribute_combination = $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "ced_1688_importer_product_attribute_combination` (
            `combination_id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
            `product_id` int(11) NOT NULL,
            `sku_id` text COLLATE utf8_unicode_ci NOT NULL,
            `combination` text COLLATE utf8_unicode_ci NOT NULL,
            `options` text COLLATE utf8_unicode_ci NOT NULL,
            `ced1688_item_id` bigint(20) NOT NULL,
            `images` longtext COLLATE utf8_unicode_ci NOT NULL,
            `response_data` longtext COLLATE utf8_unicode_ci NOT NULL,
            PRIMARY KEY (`combination_id`)
          ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
          ");

        if ($ced1688_importer_product_attribute_combination)
            $this->log("ced_1688_importer_product_attribute_combination table created", 6, true);

        // Product Chunk
        $ced_1688_importer_product_chunk = $this->db->query("
            CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "ced_1688_importer_product_chunk` (
              `id` int(11) NOT NULL AUTO_INCREMENT,
              `item_id` text NOT NULL,
              `item_data` longtext NOT NULL,
              PRIMARY KEY  (`id`)
            ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
        ");

        if ($ced_1688_importer_product_chunk)
            $this->log("ced_1688_importer_product_chunk table created", 6, true);
    }

    public function log($data, $force_log = false, $step = 6)
    {
        if ($force_log) {
            $backtrace = debug_backtrace();
            $log = new Log('ced1688importer.log');
            if (is_array($data))
                $data = json_encode($data);
            if (isset($backtrace[$step]) && isset($backtrace[$step]['class']) && isset($backtrace[$step]['class'])) {
                $log->write('(' . $backtrace[$step]['class'] . '::' . $backtrace[$step]['function'] . ') - ' . $data);
            } else {
                $log->write($data);
            }
        }
    }

    public function validateOTKey()
    {
        $status = array();
        $this->_init();
        try {
            $action = 'RunTest';
            $urlParameters = array(
                'instanceKey' => $this->otKey,
                'language' => $this->language,
                'iterationCount' => 1
            );
            $response = $this->getRequest($urlParameters, $action);
            if (isset($response['Result']['Id']) &&
                !empty($response['Result']['Id']))
            {
                $status = array('success' => true, 'message' => 'OT Key Validated successfully!');
            }
        } catch (\Exception $e) {
            $this->log('Ced1688importer::validate', 6, true);
            $this->log($e->getMessage(), 6, true);
            $status = array('success' => false, 'message' => $e->getMessage());
        }
        return $status;
    }

    public function generateUrl($urlParameters, $action)
    {
        $this->_init();
        $url_args = http_build_query($urlParameters);
        $url = $this->endpointUrl . $action . "?" . $url_args;
        return $url;
    }

    public function getRequest($urlParam, $action)
    {
        try {
            $headers = array();
            $headers[] = "Content-Type: Content=text/html; charset=us-ascii";

            $url = $this->generateUrl($urlParam, $action);

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $server_output = curl_exec($ch);

            $parsedResponse = new \SimpleXMLElement($server_output);
            $parsedResponse = json_decode(json_encode($parsedResponse), true);
            curl_close($ch);
            return $parsedResponse;
        } catch (Exception $e) {
            return array('success'=>false ,'message'=> $e->getMessage());
        }
    }

    public function prepareFilters($filters)
    {
        $this->_init();
        $preparedData = array(
            'SearchItemsParameters' => array(
                '_value' => array(),
                '_attribute' => array()
            )
        );
           $filters['provider'] = 'Alibaba1688';
        $providerArray = array();
        if (isset($filters['provider']) && !empty($filters['provider'])) {
            $providerArray['SearchItemsParameters'] = array(
                '_value' => array(
                    'Provider' => $filters['provider']
                ),
                '_attribute' => array()
            );
        }

        $preparedData['SearchItemsParameters']['_value'] = array();
        $category = isset($filters['category_id_1688']) ? $filters['category_id_1688'] : false;

        if (!empty($category)) {
            $preparedData['SearchItemsParameters'] = array(
                '_value' => array(
                    'CategoryId' => $category
                ),
                '_attribute' => array()
            );
        }

        if (!empty($filters['product_url'])) {
            if(strpos($filters['product_url'], 'http'))
                $product_url = html_entity_decode($filters['product_url']);
            else
                $product_url = $filters['product_url'];

            $preparedData['SearchItemsParameters'] = array(
                '_value' => array(
                    'ItemTitle' => trim($product_url)
                ),
                '_attribute' => array()
            );
        }

        if (isset($filters['vendor']) && !empty($filters['vendor'])) {
            $preparedData['SearchItemsParameters'] = array(
                '_value' => array(
                    'VendorName' => trim($filters['vendor'])
                ),
                '_attribute' => array()
            );
        }

        $preparedData = array_merge_recursive($preparedData, $providerArray);

        $generator = new \Generated();
        $preparedXml = $generator->arrayToXml($preparedData);

        return $preparedXml;
    }

    public function getProductData($filters, $params = array())
    {
        $this->_init();
        $action = 'BatchSearchItemsFrame';
        $urlParameters = array(
            'instanceKey' => $this->otKey,
            'language' => $this->language,
            'xmlParameters' => $filters->__toString(),
            'framePosition' => (isset($params['framePosition']) && !empty($params['framePosition']))
                ? $params['framePosition'] : 0,
            'frameSize' => (isset($params['frameSize']) && !empty($params['frameSize']))
                ? $params['frameSize'] : 1,
            'blockList' => "Vendor"
        );
           //echo '<pre>'; print_r($urlParameters); die;
        $productData = $this->getRequest($urlParameters, $action);
//        echo '<pre>'; print_r($productData); die;
        return $productData;
    }

    public function getProductsbyId($productId)
    {
        // $products = [];
        // if (is_array($productIds) && !empty($productIds))
        // {
        // foreach ($productIds as $productId)
        // {
        $action = 'BatchGetItemFullInfo';

        $urlParameters = array(
            'instanceKey' => $this->otKey,
            'language' => $this->language,
            'itemId' => $productId,
            'blockList' => "Description,Promotions,DeliveryCosts,OriginalDescription"
        );
        $products = $this->getRequest($urlParameters, $action);
        // }
        // }
        return $products;
    }

    public function googleTranslater($from_lan = '', $to_lan = '', $text = '')
    {
        $response = '';
        if (is_numeric($text)){
            $response = $text;
        } else {
            $url ='https://www.googleapis.com/language/translate/v2';
            $post = array(
                'key'=> $this->config->get('ced_1688_importer_google_api_key'),
                'source'=>$from_lan,
                'target'=>$to_lan,
                'q'=>$text
            );
            $ch = curl_init();
            curl_setopt($ch,CURLOPT_URL,$url);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            //curl_setopt($ch, CURLOPT_COOKIE,$cookie);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
            $result = curl_exec($ch);
            curl_close($ch);
            $result = json_decode($result,true);
            //echo '<pre>'; print_r($result); die;
            if(isset($result['data']['translations'][0]['translatedText']) && !empty($result['data']['translations'][0]['translatedText']))
            {
                $response = $result['data']['translations'][0]['translatedText'];
            } else {
                $response = $text;
            }
        }
        return $response;
    }

    public function getLanguages()
    {
        $sql = $this->db->query("SELECT `language_id`, `code` FROM `". DB_PREFIX ."language` ");
        if($sql->num_rows)
            return $sql->rows;
        else
            return array();
    }

    public function prepareProductData($filter_data, $product = array(), $category_id = '', $manufacturer_id = '')
    {
        $product_id = false;
        $data = array();
        if(isset($product) && is_array($product))
        {
            try {
                if (isset($filter_data) && !empty($filter_data))
                {
                    $date_available = $this->config->get('ced_1688_importer_available_date');
                    $tax_class_id = $this->config->get('ced_1688_importer_tax_class_id');
                    $length_class_id = $this->config->get('ced_1688_importer_length_class_id');
                    $weight_class_id = $this->config->get('ced_1688_importer_weight_class_id');
                    $category = $this->config->get('ced_1688_importer_product_category');
                    $store = $this->config->get('ced_1688_importer_product_store');

                    if ($this->config->get('ced_1688_importer_field_mapping')) {
                        foreach ($this->config->get('ced_1688_importer_field_mapping') as $key => $value) {
                            $data[$key] = $value;
                        }
                    }
                }

                if(empty($date_available))
                    $date_available = date('Y-m-d h:i:s a');
                if(empty($tax_class_id))
                    $tax_class_id = '9';
                if(empty($length_class_id))
                    $length_class_id = '3';
                if(empty($weight_class_id))
                    $weight_class_id = '1';
                $from_lang = $this->config->get('ced_1688_importer_language');
                $languages = $this->getLanguages();
                $store_id = $this->config->get('config_store_id');

                $existingProduct = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product` WHERE `sku` = '" . $this->db->escape($product['Id']) . "' ");

                if ($existingProduct->num_rows == 0)
                {
                    $json = array();
                    $productData = $this->getProductsbyId($product['Id']);

                    if(isset($productData['Result']['Item']) && !empty($productData['Result']['Item']))
                    {
                        $product = $productData['Result']['Item'];

                        if (isset($product['Promotions']['OtapiItemPromotion']['Price']['OriginalPrice'])
                            && !empty($product['Promotions']['OtapiItemPromotion']['Price']['OriginalPrice'])
                            && ($product['Promotions']['OtapiItemPromotion']['Price']['OriginalPrice'] != $product['Price']['OriginalPrice'])) {
                            $promotionPrice = $product['Promotions']['OtapiItemPromotion']['Price']['OriginalPrice'];
                        }

                        $ProductDataArray = array();

                        // Sku
                        if (isset($data['Sku']) && !empty($data['Sku']))
                            $ProductDataArray[$data['Sku']] = $product['Id'];
                        else
                            $ProductDataArray['sku'] = $product['Id'];

                        // Name
                        if (isset($data['name']) && !empty($data['name'])) {
                            if (!empty($product['Title']))
                                $ProductDataArray[$data['name']] = $product['Title'];
                            else
                                $ProductDataArray[$data['name']] = utf8_encode($product['OriginalTitle']);
                        } else {
                            if (!empty($product['OriginalTitle']))
                                $ProductDataArray['name'] = $product['Title'];
                            else
                                $ProductDataArray['name'] = utf8_encode($product['OriginalTitle']);
                        }

                        // Status
                        if (isset($data['Status']) && !empty($data['Status']))
                            $ProductDataArray[$data['Status']] = $product['IsSellAllowed'];
                        else
                            $ProductDataArray['status'] = $product['IsSellAllowed'];

                        // Weight
                        if ((isset($data['product_weight']) && !empty($data['product_weight'])) || (isset($data['package_weight']) && !empty($data['package_weight']))) {
                            if (($data['product_weight'] == 'weight') || ($data['package_weight'] == 'weight')) {
                                if (isset($product['PhysicalParameters']['Weight']))
                                    $ProductDataArray['weight'] = $product['PhysicalParameters']['Weight'];
                                elseif (isset($product['PhysicalParameters']['ProviderApproxWeight']))
                                    $ProductDataArray['weight'] = $product['PhysicalParameters']['ProviderApproxWeight'];
                                else
                                    $ProductDataArray['weight'] = '0.0';
                            } else if (($data['product_weight'] == 'weight_class_id') || ($data['package_weight'] == 'weight_class_id')) {
                                $ProductDataArray['weight_class_id'] = $weight_class_id;
                            }
                        }

                        if (isset($data['price']) && !empty($data['price'])) {
                            if (isset($promotionPrice) && !empty($promotionPrice)) {
                                if ($promotionPrice > $product['Price']['ConvertedPriceList']['Internal']) {
                                    $ProductDataArray[$data['price']] = (float)$promotionPrice;
                                    $promotionPrice = (float)$product['Price']['ConvertedPriceList']['Internal'];
                                } else {
                                    $ProductDataArray[$data['price']] = (float)$product['Price']['ConvertedPriceList']['Internal'];
                                }

                            } else {
                                $ProductDataArray[$data['price']] = (float)$product['Price']['ConvertedPriceList']['Internal'];
                            }

                        } else {
                            if (isset($promotionPrice) && !empty($promotionPrice)) {
                                if ($promotionPrice > $product['Price']['ConvertedPriceList']['Internal']) {
                                    $ProductDataArray['price'] = (float)$promotionPrice;
                                    $promotionPrice = (float)$product['Price']['ConvertedPriceList']['Internal'];
                                } else {
                                    $ProductDataArray['price'] = (float)$product['Price']['ConvertedPriceList']['Internal'];
                                }

                            } else {
                                $ProductDataArray['price'] = (float)$product['Price']['ConvertedPriceList']['Internal'];
                            }
                        }

                        if (isset($data['currency_id']) && !empty($data['currency_id']))
                            $ProductDataArray[$data['currency_id']] = $this->getCurrencyId($product);
                        else
                            $ProductDataArray['currency_id'] = $this->getCurrencyId($product);

                        if (isset($data['manufacturer']) && !empty($data['manufacturer']))
                            $ProductDataArray[$data['manufacturer']] = $manufacturer_id;
                        else
                            $ProductDataArray['manufacturer_id'] = $manufacturer_id;

                        if (isset($data['description']) && !empty($data['description']))
                            $ProductDataArray[$data['description']] = (isset($product['Description']) && !empty($product['Description'])) ? $product['Description'] : '';
                        else
                            $ProductDataArray['description'] = (isset($product['Description']) && !empty($product['Description'])) ? $product['Description'] : '';

                        $ProductDataArray['short_description'] = isset($product['Title']) ? $product['Title'] : utf8_encode($product['OriginalTitle']);
                        $ProductDataArray['brand'] = $product['ProviderType'];
                        $model = $product['Id'];
                        $quantity = isset($product['MasterQuantity']) ? $product['MasterQuantity'] : $product['Volume'];

                        if (isset($product['Pictures']) && !empty($product['Pictures'])) {
                            $variant_images = array();
                            foreach ($product['Pictures']['ItemPicture'] as $key => $image) {
                                if ($image['IsMain'] == 'true') {
                                    continue;
                                    // $images['0'] = $image['Url'];
                                } else {
                                    if (strpos($image['Url'], '.SS2'))
                                        $variant_images[$key] = $image['Large'];
                                    else
                                        $variant_images[$key] = $image['Url'];
                                }
                            }
                        }

                        if (empty($ProductDataArray['price']))
                            $ProductDataArray['price'] = '0.0';
                        if (empty($specialPrice))
                            $special_price = '0.0';
                        if (isset($ProductDataArray['weight_class_id']))
                            $weight_class_id = $ProductDataArray['weight_class_id'];
                        else
                            $weight_class_id = $weight_class_id;

                        if (strpos($product['MainPictureUrl'], '.SS2')) {
                            if (isset($product['Pictures']['ItemPicture']['0']) && !empty($product['Pictures']['ItemPicture']['0']) && is_array($product['Pictures']['ItemPicture']['0']) && ($product['Pictures']['ItemPicture']['0']['IsMain'] == true)) {
                                $main_img = $product['Pictures']['ItemPicture']['0']['Large'];
                                $image = $this->saveImages(array('0' => $main_img), $product['Id']);
                            }
                        } else {
                            $image = $this->saveImages(array('0' => $product['MainPictureUrl']), $product['Id']);
                        }

                        if (isset($image['0']) && $image['0'] && file_exists(DIR_IMAGE . $image['0']) && @getimagesize(DIR_IMAGE . $image['0'])) {
                            $image = $image['0'];
                        } else {
                            $image = 'no_image.png';
                        }

                        $sku = isset($ProductDataArray['sku']) ? $ProductDataArray['sku'] : $product['Id'];

                        $this->db->query("INSERT INTO `" . DB_PREFIX . "product` SET 
                          model = '" . $this->db->escape($model) . "', 
                          sku = '" . $this->db->escape($sku) . "',
                          quantity = '" . (int)$quantity . "', 
                          date_available = '" . $date_available . "',
                          price = '" . (float)$ProductDataArray['price'] . "', 
                          stock_status_id = '7', 
                          length_class_id = '" . (int)$length_class_id . "', 
                          weight_class_id = '" . (int)$weight_class_id . "',
                          status = '" . (int)$ProductDataArray['status'] . "', 
                          tax_class_id = '" . (int)$tax_class_id . "', 
                          sort_order = '1',
                          manufacturer_id = '". (int) $ProductDataArray['manufacturer_id'] ."',
                          image = '" . html_entity_decode($image) . "',
                          date_added = NOW()");

                        $product_id = $this->db->getLastId();

                        $category_id = !empty($category_id) ? $category_id : '';

                        if (!empty($category_id)) {
                            $this->db->query("INSERT INTO " . DB_PREFIX . "product_to_category SET product_id = '" . (int)$product_id . "', category_id = '" . (int)$category_id . "'");
                        } elseif (is_array($category) && !empty($category)) {
                            foreach ($category as $key => $category_id) {
                                $this->db->query("INSERT INTO " . DB_PREFIX . "product_to_category SET product_id = '" . (int)$product_id . "', category_id = '" . (int)$category_id . "'");
                            }
                        }

                        if (is_array($store) && !empty($store)) {
                            foreach ($store as $key => $store_id) {
                                $this->db->query("INSERT INTO " . DB_PREFIX . "product_to_store SET product_id = '" . (int)$product_id . "', store_id = '" . (int)$store_id . "'");
                            }
                        } elseif (!empty($store_id)) {
                            $this->db->query("INSERT INTO " . DB_PREFIX . "product_to_store SET product_id = '" . (int)$product_id . "', store_id = '" . (int)$store_id . "' ");
                        }

                        foreach ($languages as $key => $language) {
                            if (($language['code'] == 'en-gb') && ($from_lang == 'en')) {
                                $this->db->query("INSERT INTO `" . DB_PREFIX . "product_description` SET 
                                    product_id = '" . (int)$product_id . "', 
                                    language_id = '" . (int)$language['language_id'] . "',
                                    name = '" . $this->db->escape($ProductDataArray['name']) . "', 
                                    description = '" . $this->db->escape($ProductDataArray['description']) . "', 
                                    tag = '', 
                                    meta_description = '" . $this->db->escape($ProductDataArray['short_description']) . "', 
                                    meta_keyword = '', 
                                    meta_title = '" . $this->db->escape($ProductDataArray['name']) . "' 
                                    ");
                                continue;
                            }

                            $name = $this->googleTranslater($from_lang, $language['code'], $ProductDataArray['name']);
                            $description = $this->googleTranslater($from_lang, $language['code'], $ProductDataArray['description']);
                            $short_description = $this->googleTranslater($from_lang, $language['code'], $ProductDataArray['short_description']);

                            $this->db->query("INSERT INTO `" . DB_PREFIX . "product_description` SET 
                                product_id = '" . (int)$product_id . "', 
                                language_id = '" . (int)$language['language_id'] . "',
                                name = '" . $this->db->escape($name) . "', 
                                description = '" . $this->db->escape($description) . "', 
                                tag = '', 
                                meta_description = '" . $this->db->escape($short_description) . "', 
                                meta_keyword = '', 
                                meta_title = '" . $this->db->escape($name) . "' 
                            ");
                        }

                        $images = $this->saveImages($variant_images, $product_id);
                        if (isset($images) && !empty($images) && is_array($images)) {
                            $image_sort_order = '1';
                            foreach ($images as $image) {
                                if (isset($image) && $image && file_exists(DIR_IMAGE . $image) && @getimagesize(DIR_IMAGE . $image)) {
                                    $this->db->query("INSERT INTO `" . DB_PREFIX . "product_image` SET product_id = '" . (int)$product_id . "', sort_order = '" . (int)$image_sort_order . "', image = '" . $this->db->escape(html_entity_decode($image)) . "'");
                                }
                                $image_sort_order++;
                            }
                        }

                        if (isset($product['QuantityRanges']['Range']) && !empty($product['QuantityRanges']['Range']) && is_array($product['QuantityRanges']['Range'])) {
                            $priority = '1';
                            foreach ($product['QuantityRanges']['Range'] as $key => $quantityRange) {
                                $this->db->query("INSERT INTO `" . DB_PREFIX . "product_discount` SET 
                                  `product_id` = '" . (int)$product_id . "', 
                                  `customer_group_id` = '" . (int)$this->config->get('config_customer_group_id') . "',
                                  `quantity` = '" . (int)$quantityRange['MinQuantity'] . "',
                                  `priority` = '" . (int)$priority . "',
                                  `price` = '" . (float)$quantityRange['Price']['OriginalPrice'] . "'
                                 ");
                                $priority++;
                            }
                        }

                        // Special Price
                        if (isset($promotionPrice) && !empty($promotionPrice)) {
                            $this->db->query("INSERT INTO `" . DB_PREFIX . "product_special` SET 
                                `product_id` = '" . (int)$product_id . "', 
                                `customer_group_id` = '" . (int)$this->config->get('config_customer_group_id') . "',
                                `priority` = '1',
                                `price` = '" . (float)$promotionPrice . "'
                                ");
                        }

                        // Variants
                        $this->getProductVariations($product, $product_id, $variant_images);
                    } // $product by id

                } // existingProduct if ends here

                if(!empty($product_id))
                    $json = array('success' => true, 'message' => $product_id .'- Product(s) Imported Successfully!');
                elseif(!empty($existingProduct->row['product_id']))
                    $json = array('success' => true, 'message' => $existingProduct->row['product_id'] . '- Product(s) already imported!');
                else
                    $json = array('success' => false, 'message' => 'Error importing Product!');

                //} // foreach product ends here
            } catch(\Exception $e){
                //print_r($exception->getMessage());die;
                $log = new Log('ced1688_importer_product.log');
                $log->write($e->getMessage());
                $json = array('success' => false, 'message' => $e->getMessage());
            }
        }
        return $json;
    }

    public function getCurrencyId($product = array())
    {
        $currency_id = '';
        $currency_data = $this->db->query("SELECT `currency_id` FROM `". DB_PREFIX ."currency` WHERE `code` = '". $product['Price']['OriginalCurrencyCode'] ."' ");
        if(isset($currency_data->row['currency_id']) && !empty($currency_data->row['currency_id']))
        {
            $currency_id = $currency_data->row['currency_id'];
        } else {
            $convertedPriceList = $product['Price']['ConvertedPriceList']['Internal'];
            $currency_value = $product['Price']['OriginalPrice'] / $convertedPriceList;
            $this->db->query("INSERT INTO `". DB_PREFIX ."currency` SET `title` = 'Chinese Yuan', `code` = '". $product['Price']['OriginalCurrencyCode'] ."', `symbol_left` = '', `symbol_right` = '". $this->db->escape($product['Price']['CurrencySign']) ."', decimal_place = '2', `value` = '". $currency_value ."', status = '1' ");
            $currency_id = $this->db->getLastId();
        }
        return $currency_id;
    }

    public function getProductVariations($data = array(), $product_id = '', $variant_images = array())
    {
        $additionalAttributes = array();
        $attributesToCreate = array();
        try{
            if (isset($data['Attributes']['ItemAttribute']) && !empty($data['Attributes']['ItemAttribute']))
            {
                foreach ($data['Attributes']['ItemAttribute'] as $datumAtt) {
                    if ($datumAtt['IsConfigurator'] == 'false') {
                        if (isset($datumAtt['PropertyName'], $datumAtt['Value']) && !empty($datumAtt['PropertyName'])) {
                            if (isset($datumAtt['@attributes']['Pid']) && in_array($datumAtt['@attributes']['Pid'], $attributesToCreate)) {
                                $additionalAttributes[$datumAtt['PropertyName']][] = $datumAtt['Value'];
                            } else {
                                $additionalAttributes[$datumAtt['PropertyName']][] = $datumAtt['Value'];
                            }
                        }
                    }
                }
            }

            if (isset($additionalAttributes) && !empty($additionalAttributes)) {
                foreach ($additionalAttributes as $adKey => $adValue) {
                    $customAttr[$adKey] = implode(' , ', $adValue);
                }

                if(isset($customAttr) && !empty($customAttr) && is_array($customAttr))
                {
                    $this->saveAttributes($customAttr, $product_id);
                }
            }

            if (isset($data['ConfiguredItems']['OtapiConfiguredItem']) && !empty($data['ConfiguredItems']['OtapiConfiguredItem']))
            {
                $configData = $data['ConfiguredItems']['OtapiConfiguredItem'];
                if (!isset($configData[0])) {
                    $configData = array($data['ConfiguredItems']['OtapiConfiguredItem']);
                }

                $allAttributes = $data['Attributes'];
                $option_complete_data = array();
                $options = array();
                $response_data = array();
                $sort_order = '1';
                $option_value_sort_order = '1';
                $image_sort_order = '1';
                $previous_option_value_image = '';
                $previous_option_value_id = '';
                $option_images_array = array();

                foreach ($configData as $variantValues)
                {
                    $combination = array();
                    $product_option_value = array();
                    $product_option = array();

                    // Preparing attributes and images
                    $taobaoConfigurableAttributes = $this->getConfigurableAttributes($variantValues['Configurators'], $allAttributes);

                    if(isset($taobaoConfigurableAttributes['attrs']) && !empty($taobaoConfigurableAttributes['attrs']))
                    {
                        foreach($taobaoConfigurableAttributes['attrs'] as $option_value => $attribute)
                        {
                            if(isset($attribute) && ($attribute == 'size'))
                            {
                                $type = 'select';
                                $name = $option_value;
                                $option_name = ucwords($attribute);
                                $sortOrder = '2';
                            } else if(isset($attribute) && ($attribute == 'Color Classification' || $attribute == 'colour'))
                            {
                                $type = 'radio';
                                $option_name = ucwords($attribute);
                                $name = $option_value;
                                $sortOrder = '1';
                            } else {
                                if(isset($taobaoConfigurableAttributes['att_with_image']) && ($taobaoConfigurableAttributes['att_with_image'] == $attribute))
                                    $type = 'radio';
                                else
                                    $type = 'select';
                                $name = $option_value;
                                $option_name = ucwords($attribute);
                                $sortOrder = '3';
                            }

                            $from_lang = $this->config->get('ced_1688_importer_language');
                            $languages = $this->getLanguages();
                            $language_ids = array();
                            foreach($languages as $key => $language)
                            {
                                $language_ids[] = $language['language_id'];
                            }

                            if(isset($option_name) && !empty($option_name))
                            {
                                $optionExist = $this->db->query("SELECT o.`option_id` FROM `". DB_PREFIX."option` AS o LEFT JOIN `". DB_PREFIX."option_description` AS od ON (o.`option_id` = od.`option_id`) WHERE od.`name` = '". $this->db->escape($option_name) ."' AND od.`language_id` IN (" . implode(',', $language_ids) . ") AND o.`type` = '". $this->db->escape($type) ."' ");

                                if (($optionExist->num_rows == 0)) {
                                    $this->db->query("INSERT INTO `" . DB_PREFIX . "option` SET type = '". $this->db->escape($type) ."', sort_order = '". (int)$sortOrder ."' ");
                                    $option_id = $this->db->getLastId();
                                    foreach($languages as $key => $language)
                                    {
                                        if(($language['code'] == 'en-gb') && ($from_lang == 'en')){
                                            $this->db->query("INSERT INTO `" . DB_PREFIX . "option_description` SET option_id = '" . (int)$option_id . "', language_id = '" . (int)$language['language_id'] . "', name = '" . $this->db->escape($option_name) . "'");
                                            continue;
                                        }

                                        $option_name = $this->googleTranslater($from_lang, $language['code'], $option_name);

                                        $this->db->query("INSERT INTO `" . DB_PREFIX . "option_description` SET option_id = '" . (int)$option_id . "', language_id = '" . (int)$language['language_id'] . "', name = '" . $this->db->escape($option_name) . "'");
                                    }
                                } else {
                                    $option_id = $optionExist->row['option_id'];
                                }
                            }

                            try{
                                if(isset($option_id) && !empty($option_id))
                                {
                                    if(isset($taobaoConfigurableAttributes['att_with_image']) && ($taobaoConfigurableAttributes['att_with_image'] == $attribute))
                                    {
                                        if(isset($taobaoConfigurableAttributes['image']) && !empty($taobaoConfigurableAttributes['image']))
                                        {
                                            $image = $this->saveImages(array('0' => $taobaoConfigurableAttributes['image']), $product_id.$variantValues['Id']);

                                            if (isset($image['0']) && $image['0'] && file_exists(DIR_IMAGE.$image['0']) && @getimagesize(DIR_IMAGE.$image['0']))
                                            {
                                                $option_value_with_image_exist = $this->db->query("SELECT ov.`option_value_id`, ov.`image` FROM `". DB_PREFIX ."option_value` AS ov LEFT JOIN `". DB_PREFIX ."option_value_description` AS ovd ON (ov.`option_value_id` = ovd.`option_value_id`) WHERE ov.`option_id` = '". (int) $option_id ."' AND ovd.`name` = '". $this->db->escape($name) ."' AND `language_id` IN (" . implode(',', $language_ids) . ")  ");

                                                if($option_value_with_image_exist->num_rows == 0)
                                                {
                                                    $this->db->query("INSERT INTO `". DB_PREFIX."option_value` SET `option_id` = '". (int)$option_id ."', `image` = '". $this->db->escape(html_entity_decode($image['0'])) ."', `sort_order` = '". $image_sort_order ."' ");

                                                    $option_value_id = $this->db->getLastId();

                                                    foreach($languages as $key => $language)
                                                    {
                                                        if(($language['code'] == 'en-gb') && ($from_lang == 'en')){
                                                            $this->db->query("INSERT INTO `". DB_PREFIX."option_value_description` SET `option_value_id` = '". (int)$option_value_id ."', `option_id` = '". (int)$option_id ."', `language_id` = '". (int)$language['language_id'] ."', `name` = '". $this->db->escape($name) ."' ");
                                                            continue;
                                                        }

                                                        $name = $this->googleTranslater($from_lang, $language['code'], $name);

                                                        $this->db->query("INSERT INTO `". DB_PREFIX."option_value_description` SET `option_value_id` = '". (int)$option_value_id ."', `option_id` = '". (int)$option_id ."', `language_id` = '". (int)$language['language_id'] ."', `name` = '". $this->db->escape($name) ."' ");
                                                    }
                                                    $option_value_sort_order++;

                                                } else {
//                                                    if(isset($option_value_with_image_exist->row['image']) && !empty($option_value_with_image_exist->row['image']) && ($taobaoConfigurableAttributes['image'] == $previous_option_value_image ))
//                                                    {
//                                                        $option_value_id = $previous_option_value_id;
//                                                    } else
                                                    if(isset($option_value_with_image_exist->row['image']) && !empty($option_value_with_image_exist->row['image']) && in_array($taobaoConfigurableAttributes['image'], $option_images_array))
                                                    {
                                                        $option_value_id = array_search($taobaoConfigurableAttributes['image'], $option_images_array);
                                                        //$option_value_id = $key_option_value_id;
                                                    }  else {
                                                        $this->db->query("INSERT INTO `". DB_PREFIX."option_value` SET `option_id` = '". (int)$option_id ."', `image` = '". $this->db->escape(html_entity_decode($image['0'])) ."', `sort_order` = '". $image_sort_order ."' ");

                                                        $option_value_id = $this->db->getLastId();
                                                       // $previous_option_value_id = $option_value_id;

                                                        foreach($languages as $key => $language)
                                                        {
                                                            if(($language['code'] == 'en-gb') && ($from_lang == 'en')){
                                                                $this->db->query("INSERT INTO `". DB_PREFIX."option_value_description` SET `option_value_id` = '". (int)$option_value_id ."', `option_id` = '". (int)$option_id ."', `language_id` = '". (int)$language['language_id'] ."', `name` = '". $this->db->escape($name) ."' ");
                                                                continue;
                                                            }

                                                            $name = $this->googleTranslater($from_lang, $language['code'], $name);

                                                            $this->db->query("INSERT INTO `". DB_PREFIX."option_value_description` SET `option_value_id` = '". (int)$option_value_id ."', `option_id` = '". (int)$option_id ."', `language_id` = '". (int)$language['language_id'] ."', `name` = '". $this->db->escape($name) ."' ");
                                                        }
                                                        $option_value_sort_order++;
                                                    }
                                                    //$previous_option_value_image = $taobaoConfigurableAttributes['image'];
                                                }
                                                $option_images_array[$option_value_id] = $taobaoConfigurableAttributes['image'];
                                                $option_images_array = array_unique($option_images_array);
                                            }

                                        }
                                    } else {

                                        $option_value_exist = $this->db->query("SELECT ov.`option_value_id`, ovd.`name` FROM `". DB_PREFIX ."option_value` AS ov LEFT JOIN `". DB_PREFIX ."option_value_description` AS ovd ON (ov.`option_value_id` = ovd.`option_value_id`) WHERE ov.`option_id` = '". (int) $option_id ."' AND ovd.`name` = '". $this->db->escape($name) ."' AND `language_id` IN (" . implode(',', $language_ids) . ") AND ov.`image` = ''  ");

                                        if($option_value_exist->num_rows)
                                        {
                                            $result = $option_value_exist->rows;

                                            $option_value = '';
                                            foreach($result as $k => $v){
                                                $option_value .= $v['name'] . ',';
                                            }

                                            if(isset($name) && is_array($option_value) && !in_array($name, $option_value))
                                            {
                                                $this->db->query("INSERT INTO `". DB_PREFIX."option_value` SET `option_id` = '". (int)$option_id ."', `image` = '', `sort_order` = '". $image_sort_order ."' ");
                                                $option_value_id = $this->db->getLastId();

                                                foreach($languages as $key => $language)
                                                {
                                                    if(($language['code'] == 'en-gb') && ($from_lang == 'en')){
                                                        $this->db->query("INSERT INTO `". DB_PREFIX."option_value_description` SET `option_value_id` = '". (int)$option_value_id ."', `option_id` = '". (int)$option_id ."', `language_id` = '". (int)$language['language_id'] ."', `name` = '". $this->db->escape($name) ."' ");
                                                        continue;
                                                    }

                                                    $name = $this->googleTranslater($from_lang, $language['code'], $name);

                                                    $this->db->query("INSERT INTO `". DB_PREFIX."option_value_description` SET `option_value_id` = '". (int)$option_value_id ."', `option_id` = '". (int)$option_id ."', `language_id` = '". (int)$language['language_id'] ."', `name` = '". $this->db->escape($name) ."' ");
                                                }
                                                $option_value_sort_order++;
                                            } else {
                                                $option_value_exist = $this->db->query("SELECT ov.`option_value_id` FROM `". DB_PREFIX ."option_value` AS ov LEFT JOIN `". DB_PREFIX ."option_value_description` AS ovd ON (ov.`option_value_id` = ovd.`option_value_id`) WHERE ov.`option_id` = '". (int) $option_id ."' AND ovd.`name` = '". $this->db->escape($name) ."' AND `language_id` IN (" . implode(',', $language_ids) . ") AND ov.`image` = ''  ");

                                                $option_value_id = $option_value_exist->row['option_value_id'];
                                            }

                                        } else {
                                            $this->db->query("INSERT INTO `". DB_PREFIX."option_value` SET `option_id` = '". (int)$option_id ."', `image` = '', `sort_order` = '". $image_sort_order ."' ");
                                            $option_value_id = $this->db->getLastId();

                                            foreach($languages as $key => $language)
                                            {
                                                if(($language['code'] == 'en-gb') && ($from_lang == 'en')){
                                                    $this->db->query("INSERT INTO `". DB_PREFIX."option_value_description` SET `option_value_id` = '". (int)$option_value_id ."', `option_id` = '". (int)$option_id ."', `language_id` = '". (int)$language['language_id'] ."', `name` = '". $this->db->escape($name) ."' ");
                                                    continue;
                                                }

                                                $name = $this->googleTranslater($from_lang, $language['code'], $name);

                                                $this->db->query("INSERT INTO `". DB_PREFIX."option_value_description` SET `option_value_id` = '". (int)$option_value_id ."', `option_id` = '". (int)$option_id ."', `language_id` = '". (int)$language['language_id'] ."', `name` = '". $this->db->escape($name) ."' ");
                                            }
                                            $option_value_sort_order++;
                                        }
                                    }
                                }
                            } catch(Exception $e){
                                echo '<pre>'; print_r($e->getMessage()); die;
                            }
                            $optionPrice = 0;
                            if(isset($data['Promotions']['OtapiItemPromotion']['ConfiguredItems']['Item']) && !empty($data['Promotions']['OtapiItemPromotion']['ConfiguredItems']['Item']))
                            {
                                foreach($data['Promotions']['OtapiItemPromotion']['ConfiguredItems']['Item'] as $index => $variationSpecialPrice)
                                {
                                    if(isset($variationSpecialPrice['Id']) && ($variationSpecialPrice['Id'] == $variantValues['Id']))
                                    {
                                        $productMainPrice = (float) $data['Promotions']['OtapiItemPromotion']['Price']['OriginalPrice'];
                                        $variantPrice = (float) $variationSpecialPrice['Price']['OriginalPrice'];
                                        if($variantPrice >= $productMainPrice){
                                            $optionPrice = (float) $variantPrice - $productMainPrice;
                                            $price_prefix = '+';
                                        } else {
                                            $optionPrice = (float) $productMainPrice - $variantPrice;
                                            $price_prefix = '-';
                                        }
                                        break;
                                    } else{
                                        continue;
                                    }
                                }
                            } else {
                                $productMainPrice = (float) $data['Price']['OriginalPrice'];
                                $variantPrice = (float) $variantValues['Price']['OriginalPrice'];
                                if($variantPrice > $productMainPrice){
                                    $optionPrice = (float) $variantPrice - $productMainPrice;
                                    $price_prefix = '+';
                                } else {
                                    $optionPrice = (float) $productMainPrice - $variantPrice;
                                    $price_prefix = '-';
                                }
                            }

                            $option_value_id = isset($option_value_id) ? $option_value_id : '0';
                            $product_option_value[] = array(
                                'option_value_id' => $option_value_id,
                                'name' => $name,
                                'quantity' => $variantValues['Quantity'],
                                'subtract' => '0',
                                'price' => $optionPrice,
                                'price_prefix' => isset($price_prefix) ? $price_prefix : '+',
                                'points' => '0',
                                'points_prefix' => '+',
                                'weight' => '0.0',
                                'weight_prefix' => '+'
                            );

                            if($option_id && isset($product_option[$option_id]) && isset($product_option[$option_id]['type'])) {
                                $product_option[$option_id]['product_option_value'] =  $product_option_value;
                            } else if($option_id){
                                $product_option[$option_id] = array(
                                    'type' => $type,
                                    'option_id' => $option_id,
                                    'required' => '1',
                                    'product_option_value' => array(
                                        array(
                                            'option_value_id' => $option_value_id,
                                            'name' => $name,
                                            'quantity' => $variantValues['Quantity'],
                                            'subtract' => '0',
                                            'price' => $optionPrice,
                                            'price_prefix' => isset($price_prefix) ? $price_prefix : '+',
                                            'points' => '0',
                                            'points_prefix' => '+',
                                            'weight' => '0.0',
                                            'weight_prefix' => '+'
                                        ),
                                    ),
                                );
                            }

                            $combination[] = array(
                                'option_value_id' => $option_value_id,
                                'name' => $name,
                            );
                            $image_sort_order++;
                        } // $taobaoConfigurableAttributes foreach ends here
                    } // $taobaoConfigurableAttributes if ends here

                    $skuPrefix = 'ced1688';
                    $skuSuffix = isset($variantValues['Id']) ? $variantValues['Id'] : '1688';
                    $sku = trim($skuPrefix . $skuSuffix);

                    // Taking Prefix From Excel Provided Sku
                    if ($skuPrefix) {
                        $sku = trim($skuPrefix . "-{$skuSuffix}");
                    }

                    $sku = str_replace(' ', '_', $sku);

                    $options[] = array('product_option' => $product_option);
                    $response_data[] = array(
                        'sku_id' => isset($sku) ? $sku : '',
                        'combination' => isset($combination) ? $combination : '',
                        'options' => isset($taobaoConfigurableAttributes['attrs']) ? $taobaoConfigurableAttributes['attrs'] : '',
                        'item_id' => isset($variantValues['Id']) ? $variantValues['Id'] : '',
                        'images' => isset($taobaoConfigurableAttributes['image']) ? html_entity_decode($taobaoConfigurableAttributes['image']) : '',
                        'response_data' => isset($variantValues) ? $variantValues : ''
                    );

                } // $configData foreach ends here
                //   die;

                $wholeQuantity = '0';
                if (!empty($options) && is_array($options))
                {
                    foreach($options as $key => $data)
                    {
                        foreach ($data['product_option'] as $product_option)
                        {
                            //$product_option = $data['product_option'];
                            //   if ($product_option['type'] == 'select' || $product_option['type'] == 'radio')
                            if (isset($product_option['type']) && !empty($product_option['type']))
                            {
                                if (isset($product_option['product_option_value'])) {
                                    $product_option_exist = $this->db->query("SELECT `product_option_id` FROM `" . DB_PREFIX . "product_option` WHERE product_id = '" . (int)$product_id . "' AND option_id = '" . (int)$product_option['option_id'] . "' ");
                                    if($product_option_exist->num_rows == 0){
                                        $this->db->query("INSERT INTO " . DB_PREFIX . "product_option SET product_id = '" . (int)$product_id . "', option_id = '" . (int)$product_option['option_id'] . "', required = '" . (int)$product_option['required'] . "'");
                                        $product_option_id = $this->db->getLastId();
                                    } else {
                                        $product_option_id = $product_option_exist->row['product_option_id'];
                                    }

                                    foreach ($product_option['product_option_value'] as $product_option_value)
                                    {
                                        $product_option_value_exists = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_option_value WHERE product_id = '" . (int)$product_id . "' AND option_id = '" . (int)$product_option['option_id'] . "' AND option_value_id = '" . (int)$product_option_value['option_value_id'] . "' ");
                                        if($product_option_value_exists->num_rows == 0)
                                        {
                                            $wholeQuantity = $wholeQuantity + $product_option_value['quantity'];
                                            $this->db->query("INSERT INTO " . DB_PREFIX . "product_option_value SET product_option_id = '" . (int)$product_option_id . "', product_id = '" . (int)$product_id . "', option_id = '" . (int)$product_option['option_id'] . "', option_value_id = '" . (int)$product_option_value['option_value_id'] . "', quantity = '" . (int)$product_option_value['quantity'] . "', subtract = '" . (int)$product_option_value['subtract'] . "', price = '" . (float)$product_option_value['price'] . "', price_prefix = '" . $this->db->escape($product_option_value['price_prefix']) . "', points = '" . (int)$product_option_value['points'] . "', points_prefix = '" . $this->db->escape($product_option_value['points_prefix']) . "', weight = '" . (float)$product_option_value['weight'] . "', weight_prefix = '" . $this->db->escape($product_option_value['weight_prefix']) . "'");
                                        } else {
                                            $quantity = $product_option_value_exists->row['quantity'] + $product_option_value['quantity'];
                                            if($wholeQuantity == '0')
                                                $wholeQuantity = $wholeQuantity + $quantity;
                                            else
                                                $wholeQuantity = $wholeQuantity + $product_option_value['quantity'];
                                            $this->db->query("UPDATE " . DB_PREFIX . "product_option_value SET quantity = '". (int) $quantity ."'  WHERE product_option_value_id = '". $product_option_value_exists->row['product_option_value_id'] ."' ");
                                        }
                                    }
                                }
                            } else {
                                $this->db->query("INSERT INTO " . DB_PREFIX . "product_option SET product_id = '" . (int)$product_id . "', option_id = '" . (int)$product_option['option_id'] . "', value = '', required = '" . (int)$product_option['required'] . "'");
                            }
                        }
                    }
                } // options if ends here

                $productQuantity = $this->db->query("SELECT `quantity` FROM `". DB_PREFIX ."product` WHERE `product_id` = '". (int) $product_id ."' ");
                if(isset($productQuantity->row['quantity']) && ($productQuantity->row['quantity'] == '0')) {
                    $this->db->query("UPDATE `". DB_PREFIX ."product` SET quantity = '". $wholeQuantity ."' WHERE `product_id` = '". (int) $product_id ."' ");
                }

                if(isset($response_data) && !empty($response_data) && is_array($response_data))
                {
                    foreach($response_data as $key => $value)
                    {
                        $combinationExist = $this->db->query("SELECT * FROM `". DB_PREFIX ."ced_1688_importer_product_attribute_combination` WHERE `sku_id` = '". $this->db->escape($value['sku_id']) ."' ");
                        if($combinationExist->num_rows)
                        {
                            $this->db->query("UPDATE `". DB_PREFIX ."ced_1688_importer_product_attribute_combination` SET `product_id` = '". (int)$product_id ."', 
                              `sku_id` = '". $this->db->escape($value['sku_id']) ."', 
                              `combination` = '". $this->db->escape(json_encode($value['combination'])) ."', 
                              `options`  = '". $this->db->escape(json_encode($value['options'])) ."', 
                              `ced1688_item_id` = '". $this->db->escape($value['item_id']) ."',
                              `images` = '". $this->db->escape(json_encode($value['images'])) ."', 
                              `response_data` = '". $this->db->escape(json_encode($value['response_data'])) ."' 
                              WHERE `sku_id` = '". $this->db->escape($value['sku_id']) ."' ");
                        } else {
                            $this->db->query("INSERT INTO `". DB_PREFIX ."ced_1688_importer_product_attribute_combination` SET `product_id` = '". (int)$product_id ."', 
                              `sku_id` = '". $this->db->escape($value['sku_id']) ."', 
                              `combination` = '". $this->db->escape(json_encode($value['combination'])) ."', 
                              `options`  = '". $this->db->escape(json_encode($value['options'])) ."', 
                              `ced1688_item_id` = '". $this->db->escape($value['item_id']) ."',
                              `images` = '". $this->db->escape(json_encode($value['images'])) ."', 
                              `response_data` = '". $this->db->escape(json_encode($value['response_data'])) ."' ");
                        }
                    } // $response_data foreach ends here
                }
            } // $data['ConfiguredItems'] if ends here

            return 'Options Created Successfully';
        } catch(Exception $e){
            $this->log('Ced1688importer Library::getProductVariations', 6, true);
            $this->log($e->getMessage(), 6, true);
            return array('success' => false, 'message' => $e->getMessage());
        }
    }

    public function saveAttributes($customAttr, $product_id)
    {
        try{
            if(isset($customAttr) && !empty($customAttr) && is_array($customAttr))
            {
                $sort_order = '1';
                $attribute_group_id = '3';
                $from_lang = $this->config->get('ced_1688_importer_language');
                $languages = $this->getLanguages();
                $language_ids = array();
                foreach($languages as $key => $language)
                {
                    $language_ids[] = $language['language_id'];
                }

                foreach($customAttr as $key => $value)
                {
                    $attributeExist = $this->db->query("SELECT * FROM `". DB_PREFIX ."attribute_description` WHERE `name` = '". $this->db->escape($key) ."' AND language_id IN (" . implode(',', $language_ids) . ") ");
                    if($attributeExist->num_rows == 0)
                    {
                        $this->db->query("INSERT INTO `". DB_PREFIX ."attribute` SET `attribute_group_id` = '". (int) $attribute_group_id ."', `sort_order` = '". (int) $sort_order ."' ");
                        $attribute_id = $this->db->getLastId();

                        foreach($languages as $langKey => $language)
                        {
                            if(($language['code'] == 'en-gb') && ($from_lang == 'en')){
                                $this->db->query("INSERT INTO `". DB_PREFIX."attribute_description` SET `attribute_id` = '". (int) $attribute_id ."', `language_id` = '". (int)$language['language_id'] ."', `name` = '". $this->db->escape(ucwords($key)) ."' ");

                                $productAttributeExist = $this->db->query("SELECT * FROM `". DB_PREFIX ."product_attribute` WHERE `product_id` = '". (int) $product_id ."' AND `attribute_id` = '". (int) $attribute_id ."' AND `language_id` = '". (int)$language['language_id'] ."' ");
                                if($productAttributeExist->num_rows == 0)
                                    $this->db->query("INSERT INTO `". DB_PREFIX ."product_attribute` SET `product_id` = '". (int) $product_id ."', `attribute_id` = '". (int) $attribute_id ."', `language_id` = '". (int)$language['language_id'] ."', `text` = '". $this->db->escape(ucwords($value)) ."' ");
                                continue;
                            }

                            $key = $this->googleTranslater($from_lang, $language['code'], $key);

                            $this->db->query("INSERT INTO `". DB_PREFIX ."attribute_description` SET `attribute_id` = '". (int) $attribute_id ."', `language_id` = '". (int)$language['language_id'] ."', `name` = '". $this->db->escape(ucwords($key)) ."' ");

                            $productAttributeExist = $this->db->query("SELECT * FROM `". DB_PREFIX ."product_attribute` WHERE `product_id` = '". (int) $product_id ."' AND `attribute_id` = '". (int) $attribute_id ."' AND `language_id` = '". (int)$language['language_id'] ."' ");

                            if($productAttributeExist->num_rows == 0)
                            {
                                $value = $this->googleTranslater($from_lang, $language['code'], $value);
                                $this->db->query("INSERT INTO `". DB_PREFIX ."product_attribute` SET `product_id` = '". (int) $product_id ."', `attribute_id` = '". (int) $attribute_id ."', `language_id` = '". (int)$language['language_id'] ."',  `text` = '". $this->db->escape(ucwords($value)) ."' ");
                            }

                        }
                    } else {
                        $attribute_id = $attributeExist->row['attribute_id'];

                        foreach($languages as $langKey => $language)
                        {
                            if(($language['code'] == 'en-gb') && ($from_lang == 'en')){
                                $productAttributeExist = $this->db->query("SELECT * FROM `". DB_PREFIX ."product_attribute` WHERE `product_id` = '". (int) $product_id ."' AND `attribute_id` = '". (int) $attribute_id ."' AND `language_id` = '". (int)$language['language_id'] ."' ");
                                if($productAttributeExist->num_rows == 0)
                                    $this->db->query("INSERT INTO `". DB_PREFIX ."product_attribute` SET `product_id` = '". (int) $product_id ."', `attribute_id` = '". (int) $attribute_id ."', `language_id` = '". (int)$language['language_id'] ."',  `text` = '". $this->db->escape(ucwords($value)) ."' ");
                                continue;
                            }

                            $productAttributeExist = $this->db->query("SELECT * FROM `". DB_PREFIX ."product_attribute` WHERE `product_id` = '". (int) $product_id ."' AND `attribute_id` = '". (int) $attribute_id ."' AND `language_id` = '". (int)$language['language_id'] ."' ");

                            if($productAttributeExist->num_rows == 0)
                            {
                                $value = $this->googleTranslater($from_lang, $language['code'], $value);
                                $this->db->query("INSERT INTO `". DB_PREFIX ."product_attribute` SET `product_id` = '". (int) $product_id ."', `attribute_id` = '". (int) $attribute_id ."', `language_id` = '". (int)$language['language_id'] ."',  `text` = '". $this->db->escape(ucwords($value)) ."' ");
                            }
                        }
                    }
                    $sort_order++;
                }
            }
        } catch(Exception $e){
            $this->log('Ced1688Importer::saveAttributes', 6, true);
            $this->log($e->getMessage(), 6, true);
            echo '<pre>'; print_r($e->getMessage()); die;
        }
    }

    /**
     * Getting 1688 configurable attribute code
     * @param array $product
     * @return array
     */
    public function getConfigurableAttributes(array $productdata = array(), $options = array(), $child = false, $attrToEdit = false)
    {
        $configurableAttributes = array();
        $returnData = array();

        if ($child) {
            foreach ($options as $createSimpleOptions) {
                if ($createSimpleOptions['@attributes']['Vid'] == $productdata['BrandId']) {
                    continue;
                }
                $optionValue = (isset($createSimpleOptions['Value']) && !empty($createSimpleOptions['Value']))
                    ? $createSimpleOptions['Value'] : $createSimpleOptions['ValueAlias'];
                $configurableAttributes[$optionValue] = $createSimpleOptions['PropertyName'];
            }
        }

        if (isset($configurableAttributes) && empty($configurableAttributes)) {
            $attributesData = array();
            if (isset($productdata['ValuedConfigurator']['@attributes'])
                && is_array($productdata['ValuedConfigurator']['@attributes'])
                && !empty($productdata['ValuedConfigurator']['@attributes'])) {
                $attributesData[] = $productdata['ValuedConfigurator'];
            } else {
                foreach ($productdata['ValuedConfigurator'] as $proAttr) {
                    $attributesData[] = $proAttr;
                }
            }

            if(isset($options['ItemAttribute']) && is_array($options['ItemAttribute']) && !empty($options['ItemAttribute']))
            {
                foreach ($options['ItemAttribute'] as $option)
                {
                    foreach ($attributesData as $value)
                    {
                        if (isset($value['@attributes']['Vid']) && in_array($value['@attributes']['Vid'], $option['@attributes']) && isset($option['ValueAlias']))
                        {
                            $attributeName = (isset($option['Value']) && !empty($option['Value']))
                                ? $option['Value'] : $option['ValueAlias'];
                            if (isset($option['ModifiedPropertyName']))
                            {
                                $configurableAttributes['modified'][$attributeName] = $option['ModifiedPropertyName'];
                            }
                            $configurableAttributes[$attributeName] = $option['PropertyName'];
                            if (isset($option['ImageUrl']) && !empty($option['ImageUrl']))
                            {
                                $returnData['image'] = $option['ImageUrl'];
                                $returnData['mini_image'] = isset($option['MiniImageUrl']) ? $option['MiniImageUrl'] : false;
                                $returnData['att_with_image'] = $option['PropertyName'];
                            }
                        }
                    }
                }
            }
        }
        $returnData['attrs'] = $configurableAttributes;
        return $returnData;
    }

    public function saveImages($data, $productName = 'alt_prod')
    {
        $imgPaths = array();
        try {
            foreach ($data as $img) {
                $fileInfo = pathinfo($img);
                $productName = preg_replace('/[^a-zA-Z0-9\']/', '_', $productName);
                $productName = filter_var(strtolower($productName), FILTER_SANITIZE_STRING) . '.' . (isset($fileInfo['extension']) ? strtok($fileInfo['extension'], '?') : 'jpg');
                $name = 'product_image_' . str_replace('/', '_', $productName);
                $name = str_replace("'", '_', $name);
                $ch = curl_init($img);
                $fileName =  'catalog/demo/' . $name;
                if (!file_exists(DIR_IMAGE.$fileName)) {
                    $fp = fopen(DIR_IMAGE . $fileName, 'wb');
                    curl_setopt($ch, CURLOPT_FILE, $fp);
                    curl_setopt($ch, CURLOPT_HEADER, 0);
                    $response = curl_exec($ch);

                    if ($response == true) {
                        $imgPaths[] = html_entity_decode($fileName);
                    }
                    curl_close($ch);
                    fclose($fp);
                } else {
                    $imgPaths[] = html_entity_decode($fileName);
                }
            }
        } catch (\Exception $exception) {
            $log = new Log('image_saving.log');
            $log->write($exception->getMessage());
        }
        return $imgPaths;
    }
}