<?php
class ControllerCed1688ImporterColumnLeft extends Controller {
    public function eventMenu($route, &$data)
    {
        $this->load->language('extension/module/ced_1688_importer');

        $this->load->library('ced1688importer');
        $ced1688importer = Ced1688importer::getInstance($this->registry);

        // 1688 menues
        $ced_1688_menu=array();

        // 1688 Product
        if ($this->user->hasPermission('access', 'ced_1688_importer/product'))
        {
            $ced_1688_menu[] = array(
                'name'     => $this->language->get('text_product'),
                'href'     => $this->url->link('ced_1688_importer/product', 'user_token=' . $this->session->data['user_token'], true),
                'children' => array()
            );

        }

        // 1688 Configuration
        $ced_1688_menu[] = array(
            'name'     => $this->language->get('text_configuration'),
            'href'     => $this->url->link('extension/module/ced_1688_importer', 'user_token=' . $this->session->data['user_token'], true),
            'children' => array()
        );

        $data['menus'][] = array(
            'id'       => 'menu-1688',
            'icon'     => 'fa-rocket',
            'name'     => $this->language->get('text_ced_1688'),
            'href'     => '',
            'children' => $ced_1688_menu
        );

    }
}
