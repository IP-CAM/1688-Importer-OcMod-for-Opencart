<?php
// Heading
$_['heading_title'] = '1688 Importer By Cedcommerce';

//tab
$_['tab_general'] = 'Setting';
$_['tab_default'] = 'Default Values';
$_['tab_mapping'] = 'Field Mapping';

//Text
$_['text_module'] = 'Modules';
$_['text_none'] = 'None';
$_['text_yes'] = 'Modules';
$_['text_edit']= 'Edit Importer Configuration';
$_['text_success'] = 'Success: You have modified module 1688 Importer!';

// Column Left
$_['text_ced_1688'] = 'Ced 1688 Importer';
$_['text_configuration'] = 'Configuration';
$_['text_product'] = 'Product Import';
$_['text_extension'] = '1688 Module';

//Entry
$_['entry_status'] = 'Status';
$_['entry_category'] = 'Default Category';
$_['entry_store'] = 'Store(s) In Created Product';
$_['entry_weight_class'] = 'Weight Class';
$_['entry_tax_class'] = 'Tax Class';
$_['entry_length_class'] = 'Length Class';
$_['entry_available_date'] = 'Available Date';

$_['entry_ot_key'] = 'OT-Commerce Instance Key';
$_['entry_language'] = 'Default Language';
$_['entry_store'] = 'Default Store';
$_['entry_provider'] = 'Provider';
$_['entry_category'] = 'Category';
$_['entry_vendor'] = 'Vendor';
$_['entry_google_api_key'] = 'Google Translater API Key';

$_['button_get_code'] = 'Verify Key';

//Error
$_['error_permission'] = 'Warning: You do not have permission to modify module 1688 Importer!';
$_['error_ot_key'] = 'OT Key is Required.';